#include <linux/module.h>     /* Needed by all modules */ 
#include <linux/kernel.h>     /* Needed for KERN_INFO */ 
#include <linux/init.h>       /* Needed for the macros */ 

static int __init load(void) 
{ 
    printk(KERN_INFO "Loading module\n");
 
    printk(KERN_INFO "i am loaded \n"); 
    return 0; 
} 
  
static void __exit unload(void) 
{ 
    printk(KERN_INFO "bye, i am unloaded\n"); 
} 
  
module_init(load); 
module_exit(unload);

